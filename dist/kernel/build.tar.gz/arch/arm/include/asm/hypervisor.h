#ifndef _ASM_ARM_HYPERVISOR_H
#define _ASM_ARM_HYPERVISOR_H

#include <asm/xen/hypervisor.h>

#endif
