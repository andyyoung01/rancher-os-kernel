#ifndef _ALPHA_TYPES_H
#define _ALPHA_TYPES_H

#include <asm-generic/int-ll64.h>

#endif /* _ALPHA_TYPES_H */
